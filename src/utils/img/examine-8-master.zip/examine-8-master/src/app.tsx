import React, { Component } from 'react'
import AllProdacts from './components/all-prodact/all-prodacts'



export default class App extends Component {
    
    
  render() {
    return (
      <div>
        <AllProdacts />
      </div>
    )
  }
}
