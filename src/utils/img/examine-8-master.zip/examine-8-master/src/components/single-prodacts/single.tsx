import React, { Component } from 'react'

export default class Single extends Component {
  render() {
    return (
      <div>
        Single
      </div>
    )
  }
}
